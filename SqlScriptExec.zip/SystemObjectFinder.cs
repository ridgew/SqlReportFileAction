﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Text;

namespace SqlScriptExec
{
    [Flags]
    public enum ObjectType : int
    {
        /// <summary>
        /// 视图
        /// </summary>
        View = 1,
        /// <summary>
        /// 存储过程
        /// </summary>
        StoreProcedure = 2,
        /// <summary>
        /// 函数
        /// </summary>
        Function = 4
    }

    [DebuggerDisplay("名称:{Name,nq}, 类型:{Type,nq}")]
    public struct SqlObject
    {
        public ObjectType Type;
        public string DefineText;
        public string DbOwner;
        public string Name;
    }

    public class SystemObjectFinder
    {
        /// <summary>
        /// 数据库内置对象定义搜索
        /// </summary>
        /// <param name="cmd">已绑定SQL连接的Command对象</param>
        /// <param name="dbname">对象数据库</param>
        /// <param name="types">对象类型,可叠加</param>
        /// <returns></returns>
        public static List<SqlObject> QueryObjectList(SqlCommand cmd, string dbname, ObjectType types)
        {
            List<SqlObject> objList = new List<SqlObject>();
            cmd.Connection.ChangeDatabase(dbname);

            if ((types & ObjectType.View) == ObjectType.View)
            {
                ObjListFill(cmd, ObjectType.View, ref objList);
            }

            if ((types & ObjectType.StoreProcedure) == ObjectType.StoreProcedure)
            {
                ObjListFill(cmd, ObjectType.StoreProcedure, ref objList);
            }

            if ((types & ObjectType.Function) == ObjectType.Function)
            {
                ObjListFill(cmd, ObjectType.Function, ref objList);
            }

            return objList;
        }

        static void ObjListFill(SqlCommand cmd, ObjectType mType, ref List<SqlObject> objList)
        {
            string xtype = "V";

            if (mType == ObjectType.StoreProcedure)
                xtype = "P";

            if (mType == ObjectType.Function)
                xtype = "FN";

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select [name] as ObjName from sysobjects where xtype='" + xtype + "' order by [name] asc";

            using (DataTable oTab = new DataTable())
            {
                using (SqlDataAdapter adp = new SqlDataAdapter())
                {
                    adp.SelectCommand = cmd;
                    adp.Fill(oTab);
                }

                cmd.CommandText = "sp_helptext";
                cmd.CommandType = CommandType.StoredProcedure;

                StringBuilder sb = new StringBuilder();
                foreach (DataRow row in oTab.Rows)
                {
                    SqlObject obj = new SqlObject { Name = row["ObjName"].ToString(), Type = mType };
                    using (DataTable dTab = new DataTable())
                    {
                        using (SqlDataAdapter dp = new SqlDataAdapter())
                        {
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add(new SqlParameter("@objname", obj.Name));
                            dp.SelectCommand = cmd;
                            dp.Fill(dTab);
                        }
                        foreach (DataRow txtRow in dTab.Rows)
                        {
                            sb.AppendLine(txtRow["Text"].ToString().TrimEnd('\r', '\n'));
                        }
                    }
                    obj.DefineText = sb.ToString();
                    sb.Clear();
                    objList.Add(obj);
                }
            }
        }

    }


}
