﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace SqlScriptExec
{
    class Program
    {
        public static void Main(string[] args)
        {
            string logFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SqlScriptExec.log");
            if (ConfigurationManager.ConnectionStrings["SqlScriptExec"] == null)
            {
                Console.WriteLine("配置文件读取失败：没有找到键值为[SqlScriptExec]的数据库链接字符串！");
            }
            else
            {
                if (args != null && args.Length > 0)
                {
                    bool executed = false;
                    int myIndex = Array.IndexOf<string>(args, "/DbReplace");
                    if (myIndex != -1)
                    {
                        if (args.Length > myIndex + 3)
                        {
                            string sqlFileName = logFilePath.Replace(".log", ".sql");
                            string[] dbName = args[myIndex + 1].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string dname in dbName)
                            {
                                string sql = MesDbObjectReplaceWith(dname, args[myIndex + 2], args[myIndex + 3]);
                                File.AppendAllText(sqlFileName, sql);
                            }
                            string sqls = ErpSearchQueryReplaceWith(args[myIndex + 2], args[myIndex + 3]);
                            File.AppendAllText(sqlFileName, sqls);

                            Console.WriteLine("文件已生成:" + sqlFileName);
                            executed = true;
                        }
                    }

                    if (!executed)
                    {
                        #region 如果有有SQL文件则执行
                        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlScriptExec"].ConnectionString))
                        {
                            conn.Open();

                            using (SqlCommand cmd = new SqlCommand())
                            {
                                cmd.Connection = conn;
                                StringBuilder sqlB = new StringBuilder();
                                foreach (string file in args)
                                {
                                    if (!File.Exists(file))
                                        continue;

                                    try
                                    {
                                        Console.WriteLine("执行文件：" + file);
                                        string sqlAll = File.ReadAllText(file);
                                        foreach (string sql in sqlAll.Split(new string[] { "GO" }, StringSplitOptions.RemoveEmptyEntries))
                                        {
                                            if (!string.IsNullOrWhiteSpace(sql))
                                            {
                                                cmd.CommandText = sql;
                                                cmd.ExecuteNonQuery();
                                            }
                                        }
                                    }
                                    catch (Exception execErr)
                                    {
                                        Console.WriteLine("错误：" + execErr.Message);
                                        File.AppendAllText(logFilePath, "#" + file + Environment.NewLine + execErr.ToString());
                                    }
                                }
                            }

                            conn.Close();
                        }
                        Console.WriteLine("执行完成！");
                        #endregion
                    }
                }
            }

            Console.WriteLine("按任意键退出...");
            Console.Read();
        }

        public static void ObjectDefineAction(string dbname, Predicate<string> match, Action<SqlObject> foundAct)
        {
            List<SqlObject> objList = new List<SqlObject>();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlScriptExec"].ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    objList = SystemObjectFinder.QueryObjectList(cmd, dbname, ObjectType.View | ObjectType.StoreProcedure | ObjectType.Function);
                }
                conn.Close();
            }

            foreach (SqlObject obj in objList)
            {
                if (match(obj.DefineText))
                    foundAct(obj);
            }
        }

        static void ErpSearchQueryReplace(string querySql, string filedName, Predicate<string> match, Action<DataRow> foundAct)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlScriptExec"].ConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;

                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = querySql;

                    using (DataTable qTab = new DataTable())
                    {
                        using (SqlDataAdapter adp = new SqlDataAdapter())
                        {
                            adp.SelectCommand = cmd;
                            adp.Fill(qTab);
                        }

                        foreach (DataRow mRow in qTab.Rows)
                        {
                            if (match(mRow[filedName].ToString()))
                            {
                                foundAct(mRow);
                            }
                        }
                    }
                }
                conn.Close();
            }
        }

        /// <summary>
        /// 查询管理起替换
        /// </summary>
        /// <param name="sqlPattern">匹配模式</param>
        /// <param name="replaceWith">替换为</param>
        /// <returns></returns>
        public static string ErpSearchQueryReplaceWith(string sqlPattern, string replaceWith)
        {
            StringBuilder sql = new StringBuilder();
            Regex reg = new Regex(sqlPattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);
            string querySql = @"Select DBA001, DBA002, DBA007,DBA009,DBA010,DBA012,DBA014,S.SQLUser,S.SQLPassword  
                              FROM ADMDBA A with (nolock) 
                                left outer join [Server] s with (nolock) on s.ServerIP = A.DBA010
                            order by DBA001, DBA002";

            sql.AppendLine("USE DSCSYS_SLM");
            sql.AppendLine("GO");
            sql.AppendLine();

            ErpSearchQueryReplace(querySql, "DBA007", s => reg.IsMatch(s), r =>
            {
                //DBA009:数据库名 DBA010:数据库IP SQLUSer:登录用户 SQLPassword:登录密码(Base64)
                sql.AppendLine("--" + r["DBA001"].ToString() + "-" + r["DBA002"].ToString());
                sql.AppendFormat("UPDATE ADMDBA set DBA007=N'{2}' where DBA001='{0}' and DBA002='{1}' ",
                    r["DBA001"], r["DBA002"],
                    reg.Replace(r["DBA007"].ToString(), replaceWith).Replace("'", "''")
                 );
                sql.AppendLine();
                sql.AppendLine();
            });

            return sql.ToString();
        }

        /// <summary>
        /// 数据库库SQL对象调整
        /// </summary>
        /// <param name="dbname">数据库名称</param>
        /// <param name="sqlPattern">匹配模式</param>
        /// <param name="replaceWith">替换为</param>
        /// <returns></returns>
        public static string MesDbObjectReplaceWith(string dbname, string sqlPattern, string replaceWith)
        {
            StringBuilder sql = new StringBuilder();
            Regex reg = new Regex(sqlPattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);
            sql.AppendLine("USE " + dbname);
            sql.AppendLine("GO");
            sql.AppendLine();
            ObjectDefineAction(dbname, s => reg.IsMatch(s), d =>
            {
                //Console.WriteLine(string.Format("{1} 对象 [{0}] 需要替换", d.Name, d.Type));
                sql.AppendLine("--" + d.Type.ToString() + ":" + d.Name);
                sql.AppendLine(Regex.Replace(reg.Replace(d.DefineText, replaceWith), "CREATE", "ALTER", RegexOptions.IgnoreCase));
                sql.AppendLine("GO");
                sql.AppendLine();
                sql.AppendLine();
            });
            return sql.ToString();
        }
    }
}
